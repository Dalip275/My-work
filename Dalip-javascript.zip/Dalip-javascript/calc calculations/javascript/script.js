let calcbtn = document.getElementById("calcbtn");

    calcbtn.addEventListener("click", function(e) {
      e.preventDefault();

    let num1 = Number(document.getElementById("num1").value);
    let num2 = Number(document.getElementById("num2").value);
      let output = document.getElementById("output");

    let addition = num1 + num2;
    let subtraction = num1 - num2;
    let multiplication = num1 * num2;
    let division = num1 / num2;
    console.log(division); // 5

      output.innerHTML = `
      ➕ Addition of ${num1} and ${num2} = ${addition} <br>
      ➖ Subtraction of ${num1} and ${num2} = ${subtraction} <br>
       ✖ Multiplication of ${num1} and ${num2} = ${multiplication} <br>
       ➗ Division of ${num1} and ${num2} = ${division}`;
});
