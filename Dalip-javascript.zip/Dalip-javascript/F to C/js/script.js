 let calcbtn = document.getElementById("calcbtn");

    calcbtn.addEventListener("click", function(e) {
      e.preventDefault();

      let Fahrenheit = Number(document.getElementById("Fahrenheit").value);
      let output = document.getElementById("output");

 
      output.innerHTML = `${(5/9)*(Fahrenheit-32)} °C`;
});