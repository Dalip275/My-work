let temp=45;
console.log(`${temp} Fahrenheit is ${(temp-32)*(5/9)} celcius`);