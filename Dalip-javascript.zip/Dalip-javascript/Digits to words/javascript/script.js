 function numToAlpha() {
      let num = parseInt(document.getElementById("num").value);
  if (num>=1 && num<=9){
      if (num == 1) {
        alert("One");
      } 
      if (num == 2) {
        alert("Two");
      } 
      if (num == 3) {
        alert("Three");
      }
      if (num == 4) {
        alert("Four");
      } 
      if (num == 5) {
        alert("Five");
      } 
      if (num === 6) {
        alert("Six");
      } 
      if (num === 7) {
        alert("Seven");
      } 
      if (num === 8) {
        alert("Eight");
      } 
      if (num === 9) {
        alert("Nine");
      }
    }
      else {
        alert("Please enter a number between 1 and 9");
      }
    };
