 let calcbtn = document.getElementById("calcbtn");

    calcbtn.addEventListener("click", function(e) {
      e.preventDefault();

      let celsius = Number(document.getElementById("celsius").value);
      let output = document.getElementById("output");

 
      output.innerHTML = `${(9/5)*(celsius+32)} °F`;
});