name = "Sukh"       # string
age = 18            # integer
height = 5.9        # float
is_student = True   # boolean

print(name, height, is_student)
name =input("Enter your name:")
print(f"My name is {name} singh.")


age = int(input("Enter your age: "))

if age >= 18:
    print("You are an adult")
else:
    print("You are a minor")

# For loop
for i in range(1, 6):
    print(i)

# While loop
count = 1
while count <= 5:
    print(count)
    count += 1
