 function checkGrade() {
    marks =parseInt(document.getElementById("marks").value);
    if (marks >=0 && marks <=100) {
      if (marks>90) {
        alert(`Grade: A+ Pass`);
      } 
      if (marks >80 && marks<=90) {
        alert(`Grade: A Pass`);
      }
      if (marks >70 && marks<=80) {
        alert(`Grade: B Pass`);
      }
      if (marks >60 && marks<=70) {  
        alert(`Grade: B+ Pass`);
      }
      if (marks >50 && marks<=60) {
        alert(`Grade: C+ Pass`);
      } 
      if (marks >40 && marks<=50) {
        alert(`Grade: C Pass`);
      }
      if (marks<=40) {
        alert(`Grade: D Fail`);
      } 
    } 
    else {
      alert(`Enter a valid number`);
    }
  
}