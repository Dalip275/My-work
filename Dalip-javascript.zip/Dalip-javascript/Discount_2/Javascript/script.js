discount=document.getElementById("discount");
price=document.getElementById("price");

let purchase=7000;
isMember=false

if(purchase>=2500 && purchase<4500){
    console.log(`Your original bill was ₹${purchase}. After 10% discount, your total bill is ₹${purchase-(purchase*0.1)}.`);
}

else if(purchase>=4500 && purchase<6500){
    console.log(`Your original bill was ₹${purchase}. After 20% discount, your total bill is ₹${purchase-(purchase*0.2)}.`);
}

else if(purchase>6500){
    if(isMember){console.log(`Your original bill was ₹${purchase}. After 30% discount, your total bill is ₹${purchase-(purchase*0.3)} and You got a free movie ticket.`);}
    else{console.log(`Your original bill was ₹${purchase}. After 30% discount, your total bill is ₹${purchase-(purchase*0.3)}.`);}
}
else{
    console.log("Sorry! You get no discount.To get 10% or more discount, purchase should be ₹2500 or above")
}
