let temp=35;
console.log(`${temp} celcius is ${(temp*(9/5))+32} Fahrenheit`); 