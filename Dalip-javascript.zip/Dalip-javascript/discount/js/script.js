 discount=document.getElementById("discount");
 price=document.getElementById("price");

 purchase=prompt("Enter Purchase Amount");

 if(purchase>=1000){
    discount.innerText="25%";
    price.innerText=(`${purchase-(purchase*0.25)}`);

}
else{
    discount.innerText="10%";
    price.innerText=(`${purchase-(purchase*0.1)}`);
}